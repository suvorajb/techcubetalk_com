package com.tctalk.apps.album.web.delegates;

import java.util.List;

import com.tctalk.apps.album.db.businessobjects.AlbumBO;
import com.tctalk.apps.album.db.businessobjects.PhototblBO;
import com.tctalk.apps.album.db.dao.PhotoAlbumAdminDao;
import com.tctalk.apps.album.db.dao.PhotoAlbumAdminDaoImpl;

public class PhotoAlbumAdminDelegate {
	PhotoAlbumAdminDao admindao = (PhotoAlbumAdminDao) new PhotoAlbumAdminDaoImpl();
	
	// Photo Album related functions
	
	public List<AlbumBO> getAllPhotoAlbums() {
		return admindao.getAllPhotoAlbums();
	}
	
	public boolean addAlbumToCollection(AlbumBO album) {
		return admindao.addAlbum(album);
	}
	
	public boolean delAlbumFromCollection(int albumId) {
		return admindao.delAlbum(albumId);
	}
	
	//Only Photo related functions
	
	public List<PhototblBO> getAllPhotos(int albumId) {
		return admindao.getAllPhotosFromAlbum(albumId);
	}
	
	public boolean addAPhoto(PhototblBO photo) {
		return admindao.addPhotoToAlbum(photo);
	}
	
	public boolean delPhoto(int photoid) {
		return admindao.delPhotoFromAlbum(photoid);
	}
	
	public List<PhototblBO> getPhoto(int photoid) {
		return admindao.getPhoto(photoid);
	}
}