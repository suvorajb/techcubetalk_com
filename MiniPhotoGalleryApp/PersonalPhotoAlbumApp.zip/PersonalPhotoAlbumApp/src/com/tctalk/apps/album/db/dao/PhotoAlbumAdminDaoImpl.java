package com.tctalk.apps.album.db.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.tctalk.apps.album.db.businessobjects.AlbumBO;
import com.tctalk.apps.album.db.businessobjects.PhototblBO;
import com.tctalk.apps.album.utils.HibernateUtils;
import com.tctalk.apps.album.utils.PhotoAlbumConstant;

public class PhotoAlbumAdminDaoImpl implements PhotoAlbumAdminDao, PhotoAlbumConstant {

	/**
	 * The below methods will be used for handling the Photo album related
	 * operations
	 * 
	 */

	/**
	 * This function retrieves all the photo albums and send the list to the
	 * front end
	 */
	public List<AlbumBO> getAllPhotoAlbums() {
		List<AlbumBO> albumList = null;
		Session hbmSession = null;
		try {
			hbmSession = HibernateUtils.getSession();
			Criteria criteria = hbmSession.createCriteria(AlbumBO.class);
			albumList = criteria.list();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			HibernateUtils.closeSession(hbmSession);
		}

		return albumList;
	}

	/**
	 * This function adds one photo album to the database
	 */
	public boolean addAlbum(AlbumBO album) {
		Session hbmSession = null;
		boolean STATUS_FLAG = true;
		try {
			hbmSession = HibernateUtils.getSession();
			hbmSession.beginTransaction();

			// change the creation date to today's date in the album object
			album.setAlbumcreatedate(new Date());
			// add the album to the hibernate session to save
			hbmSession.save(album);
			hbmSession.getTransaction().commit();
		} catch (Exception ex) {
			hbmSession.getTransaction().rollback();
			ex.printStackTrace();
			STATUS_FLAG = false;
		} finally {
			HibernateUtils.closeSession(hbmSession);
		}
		return STATUS_FLAG;
	}

	/**
	 * This function deletes the photoalbum based on the album id. It first
	 * check if the album has any photos or not. If the album is not emptry then
	 * it deletes the photos first and then delete the album itself
	 */
	public boolean delAlbum(int albumId) {
		Session hbmSession = null;
		boolean STATUS_FLAG = true;
		try {
			// get the hibernate session to perform delete operation
			hbmSession = HibernateUtils.getSession();
			hbmSession.beginTransaction();
			
			//delete all photos from the Photo table correspond to the album id
			Query query = hbmSession.createQuery(_HQL_DEL_PHOTOS_ALBUM);
			query.setInteger("albumid", new Integer(albumId));
			int rowCount = query.executeUpdate();
	        System.out.println("Rows affected: " + rowCount);
			
			//now load the album object from Album table and delete it correspond to the album id
			AlbumBO albumObj = (AlbumBO) hbmSession.load(AlbumBO.class, albumId);
			hbmSession.delete(albumObj);
			
			hbmSession.getTransaction().commit();
		} catch (Exception ex) {
			hbmSession.getTransaction().rollback();
			ex.printStackTrace();
			STATUS_FLAG = false;
		} finally {
			HibernateUtils.closeSession(hbmSession);
		}
		return STATUS_FLAG;
	}

	/**
	 * The below functions will be helpful to work on the Photos in the photo
	 * album
	 */

	/**
	 * This function retrieves all the photos and send the list to the front end
	 */
	public List<PhototblBO> getAllPhotosFromAlbum(int albumid) {
		List<PhototblBO> photoList = null;
		Session hbmSession = null;
		Criteria criteria = null;

		try {
			hbmSession = HibernateUtils.getSession();
			hbmSession.beginTransaction();

			// retrieve all photos from photo table correspond to the album Id
			criteria = hbmSession.createCriteria(PhototblBO.class).add(
					Restrictions.eq("albumid", albumid));
			photoList = criteria.list();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			HibernateUtils.closeSession(hbmSession);
		}
		return photoList;
	}

	/**
	 * This function adds photo to the album
	 */
	public boolean addPhotoToAlbum(PhototblBO photoobj) {
		Session hbmSession = null;
		boolean STATUS_FLAG = true;
		try {
			hbmSession = HibernateUtils.getSession();
			hbmSession.beginTransaction();
			hbmSession.save(photoobj);
			hbmSession.getTransaction().commit();
		} catch (Exception ex) {
			hbmSession.getTransaction().rollback();
			ex.printStackTrace();
			STATUS_FLAG = false;
		} finally {
			HibernateUtils.closeSession(hbmSession);
		}
		return STATUS_FLAG;
	}

	/**
	 * This function deletes the photo from the album itself
	 */
	public boolean delPhotoFromAlbum(int photoid) {
		Session hbmSession = null;
		boolean STATUS_FLAG = true;

		try {
			// get the hibernate session to perform delete operation
			hbmSession = HibernateUtils.getSession();
			hbmSession.beginTransaction();
			PhototblBO photoobj = (PhototblBO) hbmSession.load(
					PhototblBO.class, photoid);
			hbmSession.delete(photoobj);
			hbmSession.getTransaction().commit();
		} catch (Exception ex) {
			hbmSession.getTransaction().rollback();
			ex.printStackTrace();
			STATUS_FLAG = false;
		} finally {
			HibernateUtils.closeSession(hbmSession);
		}
		return STATUS_FLAG;
	}

	/**
	 * This function returns the photo object itself
	 */
	public List<PhototblBO> getPhoto(int photoid) {
		List<PhototblBO> photoList = null;
		Session hbmSession = null;
		Criteria criteria = null;

		try {
			hbmSession = HibernateUtils.getSession();
			hbmSession.beginTransaction();

			// retrieve all photos from photo table correspond to the album Id
			criteria = hbmSession.createCriteria(PhototblBO.class).add(
					Restrictions.eq("photoid", photoid));
			photoList = criteria.list();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			HibernateUtils.closeSession(hbmSession);
		}
		return photoList;
	}

}
