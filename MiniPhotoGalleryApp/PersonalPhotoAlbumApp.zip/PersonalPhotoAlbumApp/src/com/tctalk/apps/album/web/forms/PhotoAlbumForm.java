package com.tctalk.apps.album.web.forms;

import java.io.File;
import java.util.List;

import com.opensymphony.xwork2.ActionSupport;
import com.tctalk.apps.album.db.businessobjects.AlbumBO;
import com.tctalk.apps.album.db.businessobjects.PhototblBO;

public class PhotoAlbumForm extends ActionSupport{

	private static final long 	serialVersionUID 		 = 706337856877546963L;

	private List<AlbumBO> 		albumList 				 = null;
	private List<PhototblBO> 	photoList 				 = null;
	
	private AlbumBO 			album					 = null;
	private PhototblBO 			photobo					 = null;
	
	private File 				fileUpload;
	private String 				fileUploadContentType;
	private String 				fileUploadFileName;
	private String 				photoTitle;
	private int 				photoid;
	private int 				albumid;
 
	public String getFileUploadContentType() {
		return fileUploadContentType;
	}
 
	public void setFileUploadContentType(String fileUploadContentType) {
		this.fileUploadContentType = fileUploadContentType;
	}
 
	public String getFileUploadFileName() {
		return fileUploadFileName;
	}
 
	public void setFileUploadFileName(String fileUploadFileName) {
		this.fileUploadFileName = fileUploadFileName;
	}
 
	public File getFileUpload() {
		return fileUpload;
	}
 
	public void setFileUpload(File fileUpload) {
		this.fileUpload = fileUpload;
	}
 
	public String getPhotoTitle() {
		return photoTitle;
	}

	public void setPhotoTitle(String photoTitle) {
		this.photoTitle = photoTitle;
	}
	
	public List<AlbumBO> getAlbumList() {
		return albumList;
	}
	public void setAlbumList(List<AlbumBO> albumList) {
		this.albumList = albumList;
	}
	public List<PhototblBO> getPhotoList() {
		return photoList;
	}
	public void setPhotoList(List<PhototblBO> photoList) {
		this.photoList = photoList;
	}
	public AlbumBO getAlbum() {
		return album;
	}
	public void setAlbum(AlbumBO album) {
		this.album = album;
	}
	public PhototblBO getPhotobo() {
		return photobo;
	}
	public void setPhotobo(PhototblBO photobo) {
		this.photobo = photobo;
	}
	public int getPhotoid() {
		return photoid;
	}
	public void setPhotoid(int photoid) {
		this.photoid = photoid;
	}
	public int getAlbumid() {
		return albumid;
	}
	public void setAlbumid(int albumid) {
		this.albumid = albumid;
	}
}
