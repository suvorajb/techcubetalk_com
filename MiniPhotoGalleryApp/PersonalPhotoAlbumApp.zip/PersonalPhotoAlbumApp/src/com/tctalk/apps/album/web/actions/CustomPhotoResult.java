package com.tctalk.apps.album.web.actions;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.Result;

public class CustomPhotoResult implements Result {
	
	private static final long serialVersionUID = 1L;

	public void execute(ActionInvocation invocation) throws Exception {
		PhotoAlbumAdminAction action = (PhotoAlbumAdminAction) invocation.getAction();
		HttpServletResponse response = ServletActionContext.getResponse();
		
		response.setContentType(action.getPhotobo().getImgcontenttype());
		response.setHeader("Content-Disposition", "inline; filename=\""	+ action.getPhotobo().getPhotoname() + "\"");
		response.setHeader("cache-control", "no-cache");
		response.getOutputStream().write(action.getPhotobo().getPhotodata());
		response.getOutputStream().flush();
		response.getOutputStream().close();
	}
}
