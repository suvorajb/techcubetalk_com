package com.tctalk.apps.album.web.actions;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;

import com.tctalk.apps.album.db.businessobjects.AlbumBO;
import com.tctalk.apps.album.db.businessobjects.PhototblBO;
import com.tctalk.apps.album.web.delegates.PhotoAlbumAdminDelegate;
import com.tctalk.apps.album.web.forms.PhotoAlbumForm;

public class PhotoAlbumAdminAction extends PhotoAlbumForm {

	private static final long serialVersionUID = 9168149105719285096L;
	private PhotoAlbumAdminDelegate delegate = new PhotoAlbumAdminDelegate();

	public String getAllAlbumList() {
		List<AlbumBO> albumList = delegate.getAllPhotoAlbums();
		String returnString = ERROR;

		if (albumList != null) {
			setAlbumList(albumList);
			returnString = SUCCESS;
		}
		return returnString;
	}

	public String addAlbumToCollection() {
		String returnString = ERROR;
		AlbumBO album = getAlbum();

		if (delegate.addAlbumToCollection(album)) {
			returnString = SUCCESS;
		}

		return returnString;
	}

	public String delAlbumFromCollection() {
		String returnString = ERROR;

		int albumId = getAlbumid();
		if (delegate.delAlbumFromCollection(albumId)) {
			returnString = SUCCESS;
		}

		return returnString;
	}

	public String listAllPhotos() {
		List<PhototblBO> photoList = delegate.getAllPhotos(this.getAlbumid());
		String returnString = ERROR;

		if (photoList != null) {
			this.setPhotoList(photoList);
			returnString = SUCCESS;
		}
		return returnString;
	}

	public String uploadPhotoToAlbum() {
		String returnString = ERROR;
		PhototblBO photoBO = new PhototblBO();

		// set the uploaded file meta data to the PhototblBO object before
		// saving to database
		photoBO.setAlbumid(getAlbumid());
		photoBO.setPhotocreatedate(new Date());
		photoBO.setImgcontenttype(getFileUploadContentType());
		photoBO.setPhotoname(getFileUploadFileName());
		photoBO.setPhototitle(getPhotoTitle());
		try {
			// the uploaded file is in File format so we need to convert to
			// byte[] array for storing in our database. For this apache 
			//common file utility class is used below.
			photoBO.setPhotodata(FileUtils.readFileToByteArray(getFileUpload()));
		} catch (IOException e) {
			e.printStackTrace();
		}

		setPhotobo(photoBO);
		setAlbumid(photoBO.getAlbumid());
		if (delegate.addAPhoto(getPhotobo())) {
			returnString = SUCCESS;
		}

		return returnString;
	}

	public String delPhoto() {
		String returnString = ERROR;

		int photoId = getPhotoid();
		if (delegate.delPhoto(photoId)) {
			returnString = SUCCESS;
		}

		return returnString;
	}
	
	public String showPhoto() {
		String returnString = ERROR;
		List<PhototblBO> photoList = delegate.getPhoto(this.getPhotoid());
		
		if (photoList != null) {
			PhototblBO photoBO = (PhototblBO)photoList.get(0);
			if(photoBO != null){
				setPhotobo(photoBO);
				returnString = SUCCESS;
			}
		}
		return returnString;
	}
	
}
