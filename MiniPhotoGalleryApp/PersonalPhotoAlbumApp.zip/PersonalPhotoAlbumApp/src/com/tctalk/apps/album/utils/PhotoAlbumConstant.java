package com.tctalk.apps.album.utils;

public interface PhotoAlbumConstant {

	String _HIBERNATE_CONFIG_LOCATION = "hibernate.cfg.xml";
	String _HQL_DEL_PHOTOS_ALBUM = "DELETE FROM PhototblBO WHERE albumid= :albumid";	
}
