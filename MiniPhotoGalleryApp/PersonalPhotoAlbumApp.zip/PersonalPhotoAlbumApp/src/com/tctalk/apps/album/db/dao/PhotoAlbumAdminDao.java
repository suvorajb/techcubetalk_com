package com.tctalk.apps.album.db.dao;

import java.util.List;

import com.tctalk.apps.album.db.businessobjects.AlbumBO;
import com.tctalk.apps.album.db.businessobjects.PhototblBO;

public interface PhotoAlbumAdminDao {
	// Photo Album related operations
	public List<AlbumBO> getAllPhotoAlbums();	
	public boolean addAlbum(AlbumBO album);
	public boolean delAlbum(int albumId);
	
	//Photo related operations
	public List<PhototblBO> getAllPhotosFromAlbum(int albumid);
	public boolean addPhotoToAlbum(PhototblBO photo);
	public boolean delPhotoFromAlbum(int photoid);
	public List<PhototblBO> getPhoto(int photoid);
}
