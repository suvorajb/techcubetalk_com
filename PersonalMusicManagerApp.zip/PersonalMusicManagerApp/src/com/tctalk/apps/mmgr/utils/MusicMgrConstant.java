package com.tctalk.apps.mmgr.utils;

public interface MusicMgrConstant {

	String _HIBERNATE_CONFIG_LOCATION = "hibernate.cfg.xml";
}
